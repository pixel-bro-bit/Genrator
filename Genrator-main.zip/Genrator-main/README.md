# Genrator
Generates a website for you
